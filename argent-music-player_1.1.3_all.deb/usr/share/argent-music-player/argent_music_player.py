#!/usr/bin/env python3
"""Argent Music Player v1.1.3 - GTK4 + libadwaita + GStreamer + SQLite
Correcciones v1.1.3:
  - Crossfade respeta la duracion elegida por el usuario
  - MPRIS2 completo (Stop/Seek/SetPosition/OpenUri, LoopStatus/Shuffle en Set)
  - PlayQueue._build no inserta indice -1 con cola vacia
  - PlayQueue.add no re-shufflea toda la cola
  - MiniPlayer no se congela tras ocultar/mostrar
  - LRC respeta [offset:] y precision de milisegundos
  - Crossfade omitido en REPEAT_ONE (no reproduce doble la misma pista)
  - Acceso a BD con lock en arbol de carpetas
  - _sync_list_highlight actualiza solo las filas afectadas
  - urllib.error importado (evita NameError en manejador HTTP)
  - _on_next notifica a MPRIS al detenerse
  - _play_current protegido con try/except
  - Cola vacia resetea UI del reproductor
  - TagEditorDialog no cierra si el guardado falla
  - Cache de pixbuf por cancion
  - Contador de errores consecutivos evita cascada infinita
  - Color dominante protegido contra carreras con token
"""

import os, sys, gi, threading, sqlite3, base64, struct, json
import urllib.error
from mutagen import File as MutagenFile
from pathlib import Path

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Gst", "1.0")
from gi.repository import Gtk, Adw, Gst, GLib, Gio, GdkPixbuf, Gdk, Pango, GObject as GObj

Gst.init(None)

SUPPORTED_FORMATS = {".mp3",".flac",".ogg",".opus",".m4a",".aac",".wav",".wma",".ape",".mpc",".wv"}
REPEAT_NONE, REPEAT_ONE, REPEAT_ALL = 0, 1, 2
DB_PATH   = os.path.expanduser("~/.local/share/argent-music-player/library.db")
CONF_PATH = os.path.expanduser("~/.local/share/argent-music-player/config.json")

def load_config():
    try:
        with open(CONF_PATH,"r",encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_config(cfg):
    try:
        os.makedirs(os.path.dirname(CONF_PATH), exist_ok=True)
        with open(CONF_PATH,"w",encoding="utf-8") as f:
            json.dump(cfg, f)
    except Exception as e:
        print(f"[config] No se pudo guardar: {e}")

EQ_BANDS = [29, 59, 119, 237, 474, 947, 1889, 3770, 7523, 15011]
EQ_PRESETS = {
    "Plano":       [0,0,0,0,0,0,0,0,0,0],
    "Bass Boost":  [6,5,4,2,0,0,0,0,0,0],
    "Treble":      [0,0,0,0,0,2,3,4,5,6],
    "Pop":         [-1,2,4,4,2,0,-1,-1,-1,-1],
    "Rock":        [4,3,2,0,-1,0,2,3,3,3],
    "Clasica":     [4,3,2,0,0,0,0,0,2,3],
    "Electronica": [4,3,0,-2,-1,2,3,3,2,3],
    "Acustica":    [3,2,1,0,0,0,1,2,2,2],
}

MPRIS2_XML = """<node>
  <interface name="org.mpris.MediaPlayer2">
    <method name="Raise"/><method name="Quit"/>
    <property name="CanQuit" type="b" access="read"/>
    <property name="CanRaise" type="b" access="read"/>
    <property name="HasTrackList" type="b" access="read"/>
    <property name="Identity" type="s" access="read"/>
    <property name="SupportedUriSchemes" type="as" access="read"/>
    <property name="SupportedMimeTypes" type="as" access="read"/>
  </interface>
  <interface name="org.mpris.MediaPlayer2.Player">
    <method name="Next"/><method name="Previous"/>
    <method name="Pause"/><method name="PlayPause"/>
    <method name="Stop"/><method name="Play"/>
    <method name="Seek"><arg type="x" direction="in"/></method>
    <method name="SetPosition"><arg type="o" direction="in"/><arg type="x" direction="in"/></method>
    <method name="OpenUri"><arg type="s" direction="in"/></method>
    <signal name="Seeked"><arg type="x"/></signal>
    <property name="PlaybackStatus" type="s" access="read"/>
    <property name="LoopStatus"     type="s" access="readwrite"/>
    <property name="Rate"           type="d" access="readwrite"/>
    <property name="Shuffle"        type="b" access="readwrite"/>
    <property name="Metadata"       type="a{sv}" access="read"/>
    <property name="Volume"         type="d" access="readwrite"/>
    <property name="Position"       type="x" access="read"/>
    <property name="MinimumRate"    type="d" access="read"/>
    <property name="MaximumRate"    type="d" access="read"/>
    <property name="CanGoNext"      type="b" access="read"/>
    <property name="CanGoPrevious"  type="b" access="read"/>
    <property name="CanPlay"        type="b" access="read"/>
    <property name="CanPause"       type="b" access="read"/>
    <property name="CanSeek"        type="b" access="read"/>
    <property name="CanControl"     type="b" access="read"/>
  </interface>
</node>"""

# ══ Song ═══════════════════════════════════════════════════════════════
class Song:
    def __init__(self, path, title="", artist="", album="", genre="", duration=0, tracknumber=0):
        self.path=path; self.title=title or Path(path).stem
        self.artist=artist or "Artista desconocido"
        self.album=album or "Album desconocido"
        self.genre=genre or ""; self.duration=duration; self.tracknumber=tracknumber
        self.cover=None; self._cover_loaded=False
        self._pixbuf_cache = None

    @classmethod
    def from_path(cls, path):
        s=cls(path); name=Path(path).stem
        try:
            ext=Path(path).suffix.lower()
            if ext in (".opus", ".ogg"):
                from mutagen.oggopus import OggOpus
                from mutagen.oggvorbis import OggVorbis
                try:
                    raw = OggOpus(path) if ext==".opus" else OggVorbis(path)
                    def vget(key, default):
                        v = raw.tags.get(key) or raw.tags.get(key.upper())
                        return v[0] if v else default
                    s.title  = vget("title",  name)
                    s.artist = vget("artist", "Artista desconocido")
                    s.album  = vget("album",  "Album desconocido")
                    s.genre  = vget("genre",  "")
                    tr = vget("tracknumber", None)
                    if tr:
                        try: s.tracknumber=int(str(tr).split("/")[0])
                        except: pass
                    if hasattr(raw,"info") and hasattr(raw.info,"length"):
                        s.duration=int(raw.info.length)
                    return s
                except Exception:
                    pass

            audio=MutagenFile(path, easy=True)
            if audio is None: return s
            t=audio.get("title",[None])[0]; s.title=str(t) if t else name
            s.artist=str(audio.get("artist",["Artista desconocido"])[0])
            s.album =str(audio.get("album", ["Album desconocido"])[0])
            s.genre =str(audio.get("genre", [""])[0])
            tr=audio.get("tracknumber",[None])[0]
            if tr:
                try: s.tracknumber=int(str(tr).split("/")[0])
                except: pass
            if hasattr(audio,"info") and hasattr(audio.info,"length"):
                s.duration=int(audio.info.length)
        except: pass
        return s

    def load_cover(self):
        if self._cover_loaded: return
        self._cover_loaded=True
        try:
            raw=MutagenFile(self.path)
            if raw is None: return
            if hasattr(raw,"tags") and raw.tags:
                for k in raw.tags.keys():
                    if k.startswith("APIC"): self.cover=raw.tags[k].data; return
            if hasattr(raw,"pictures") and raw.pictures:
                self.cover=raw.pictures[0].data; return
            if hasattr(raw,"tags") and raw.tags and "covr" in raw.tags:
                self.cover=bytes(raw.tags["covr"][0]); return
            if hasattr(raw,"tags") and raw.tags:
                for k in ("metadata_block_picture","METADATA_BLOCK_PICTURE"):
                    if k in raw.tags:
                        data=base64.b64decode(raw.tags[k][0]); off=4
                        ml=struct.unpack(">I",data[off:off+4])[0]; off+=4+ml
                        dl=struct.unpack(">I",data[off:off+4])[0]; off+=4+dl+16
                        il=struct.unpack(">I",data[off:off+4])[0]; off+=4
                        self.cover=data[off:off+il]; return
        except: pass

    def get_pixbuf(self):
        """Devuelve el Pixbuf cacheado o None si no hay portada."""
        if self._pixbuf_cache is not None:
            return self._pixbuf_cache
        self.load_cover()
        if not self.cover:
            return None
        try:
            ld = GdkPixbuf.PixbufLoader()
            ld.write(self.cover)
            ld.close()
            self._pixbuf_cache = ld.get_pixbuf()
            return self._pixbuf_cache
        except Exception:
            return None

    def invalidate_cover(self):
        """Llamar tras editar la portada."""
        self._pixbuf_cache = None
        self._cover_loaded = False
        self.cover = None

    @property
    def display_title(self):
        return f"{self.tracknumber:02d}. {self.title}" if self.tracknumber else self.title
    @property
    def filename(self): return Path(self.path).stem
    @property
    def duration_str(self):
        m,s=divmod(self.duration,60); h,m=divmod(m,60)
        return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

# ══ Database ════════════════════════════════════════════════════════════
class MusicDatabase:
    def __init__(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        self.conn=sqlite3.connect(DB_PATH, check_same_thread=False)
        self._lock = threading.Lock()
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS songs(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path TEXT UNIQUE NOT NULL, title TEXT, artist TEXT,
                album TEXT, genre TEXT, duration INTEGER DEFAULT 0,
                tracknumber INTEGER DEFAULT 0, folder TEXT);
            CREATE INDEX IF NOT EXISTS idx_artist ON songs(artist);
            CREATE INDEX IF NOT EXISTS idx_album  ON songs(album);
            CREATE INDEX IF NOT EXISTS idx_genre  ON songs(genre);
            CREATE INDEX IF NOT EXISTS idx_folder ON songs(folder);
        """); self.conn.commit()

    def upsert(self, s, folder):
        with self._lock:
            self.conn.execute("""
                INSERT INTO songs(path,title,artist,album,genre,duration,tracknumber,folder)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(path) DO UPDATE SET
                  title=excluded.title, artist=excluded.artist, album=excluded.album,
                  genre=excluded.genre, duration=excluded.duration,
                  tracknumber=excluded.tracknumber, folder=excluded.folder
            """,(s.path,s.title,s.artist,s.album,s.genre,s.duration,s.tracknumber,folder))

    def commit(self):
        with self._lock:
            self.conn.commit()

    def remove_missing(self, folder):
        with self._lock:
            rows=self.conn.execute("SELECT path FROM songs WHERE folder=?",(folder,)).fetchall()
            bad=[r[0] for r in rows if not os.path.exists(r[0])]
            if bad:
                self.conn.executemany("DELETE FROM songs WHERE path=?",[(p,) for p in bad])
                self.conn.commit()

    def _rs(self, rows): return [Song(r[0],r[1],r[2],r[3],r[4],r[5],r[6]) for r in rows]

    def all_songs(self):
        with self._lock:
            return self._rs(self.conn.execute("""SELECT path,title,artist,album,genre,duration,tracknumber FROM songs
                ORDER BY artist COLLATE NOCASE,album COLLATE NOCASE,tracknumber,title COLLATE NOCASE""").fetchall())

    def songs_in_folder(self, folder):
        with self._lock:
            return self._rs(self.conn.execute("""SELECT path,title,artist,album,genre,duration,tracknumber FROM songs
                WHERE folder=? ORDER BY artist COLLATE NOCASE,album COLLATE NOCASE,tracknumber,title COLLATE NOCASE""",(folder,)).fetchall())

    def songs_by_artist(self, artist):
        with self._lock:
            return self._rs(self.conn.execute("""SELECT path,title,artist,album,genre,duration,tracknumber FROM songs
                WHERE artist=? ORDER BY album COLLATE NOCASE,tracknumber,title COLLATE NOCASE""",(artist,)).fetchall())

    def songs_by_album(self, album, artist):
        with self._lock:
            return self._rs(self.conn.execute("""SELECT path,title,artist,album,genre,duration,tracknumber FROM songs
                WHERE album=? AND artist=? ORDER BY tracknumber,title COLLATE NOCASE""",(album,artist)).fetchall())

    def songs_by_genre(self, genre):
        with self._lock:
            return self._rs(self.conn.execute("""SELECT path,title,artist,album,genre,duration,tracknumber FROM songs
                WHERE COALESCE(NULLIF(genre,''),'Sin genero')=?
                ORDER BY artist COLLATE NOCASE,title COLLATE NOCASE""",(genre,)).fetchall())

    def update_tags(self, path, title, artist, album, genre, tracknumber):
        with self._lock:
            self.conn.execute("""UPDATE songs SET title=?,artist=?,album=?,genre=?,tracknumber=?
                WHERE path=?""",(title,artist,album,genre,tracknumber,path))
            self.conn.commit()

    def all_artists(self):
        with self._lock:
            return self.conn.execute("""SELECT artist,COUNT(*) FROM songs
                GROUP BY artist COLLATE NOCASE ORDER BY artist COLLATE NOCASE""").fetchall()

    def all_albums(self):
        with self._lock:
            return self.conn.execute("""SELECT album,artist,COUNT(*) FROM songs
                GROUP BY album COLLATE NOCASE,artist COLLATE NOCASE
                ORDER BY artist COLLATE NOCASE,album COLLATE NOCASE""").fetchall()

    def all_genres(self):
        with self._lock:
            return self.conn.execute("""SELECT COALESCE(NULLIF(genre,''),'Sin genero') as g,COUNT(*)
                FROM songs GROUP BY g ORDER BY g COLLATE NOCASE""").fetchall()

    def is_indexed(self, folder):
        with self._lock:
            return self.conn.execute("SELECT COUNT(*) FROM songs WHERE folder=?",(folder,)).fetchone()[0]>0

    def needs_rescan(self, folder):
        with self._lock:
            indexed=set(r[0] for r in self.conn.execute("SELECT path FROM songs WHERE folder=?",(folder,)).fetchall())
        for root,_,files in os.walk(folder):
            for f in files:
                if Path(f).suffix.lower() in SUPPORTED_FORMATS:
                    if os.path.join(root,f) not in indexed: return True
        return False

    def folder_list(self):
        """Carpetas distintas indexadas (seguro desde la UI)."""
        with self._lock:
            return [r[0] for r in self.conn.execute(
                "SELECT DISTINCT folder FROM songs ORDER BY folder").fetchall() if r[0]]

    def folder_count(self, folder):
        with self._lock:
            return self.conn.execute(
                "SELECT COUNT(*) FROM songs WHERE folder=?", (folder,)).fetchone()[0]

# ══ AudioEngine con EQ + Crossfade ═════════════════════════════════════
class AudioEngine:
    XFADE_STEP_MS = 50

    def __init__(self, on_eos, on_error, on_position):
        self.on_eos=on_eos; self.on_error=on_error; self.on_position=on_position
        self._vol=1.0; self._xfade_secs=0; self._xfading=False
        self._xfade_step=0
        self._xfade_total=20                # se recalcula al iniciar cada fade
        self._xfade_timeout_id = 0
        self._band_gains = [0.0] * 10

        self._players=[
            Gst.ElementFactory.make("playbin3","playerA"),
            Gst.ElementFactory.make("playbin3","playerB"),
        ]
        self._active=0

        self.eq = None
        self.eq_available = False
        self._eq_bins = [None, None]
        self._eqs = [None, None]

        for i, p in enumerate(self._players):
            eq = Gst.ElementFactory.make("equalizer-10bands", f"eq{i}")
            if eq is None:
                continue
            try:
                fbin = Gst.Bin.new(f"eq-bin{i}")
                conv = Gst.ElementFactory.make("audioconvert", f"eq-conv{i}")
                fbin.add(eq)
                if conv:
                    fbin.add(conv)
                    conv.link(eq)
                    pad_in = Gst.GhostPad.new("sink", conv.get_static_pad("sink"))
                else:
                    pad_in = Gst.GhostPad.new("sink", eq.get_static_pad("sink"))
                pad_out = Gst.GhostPad.new("src", eq.get_static_pad("src"))
                fbin.add_pad(pad_in); fbin.add_pad(pad_out)
                p.set_property("audio-filter", fbin)
                self._eq_bins[i] = fbin
                self._eqs[i] = eq
                if i == 0:
                    self.eq = eq
                    self.eq_available = True
            except Exception:
                self._eq_bins[i] = None
                self._eqs[i] = None

        for i, p in enumerate(self._players):
            bus = p.get_bus()
            bus.add_signal_watch()
            bus.connect("message::error", lambda b, m, pl=p: self._on_err(m))
            bus.connect("message::eos", lambda b, m, idx=i: self._on_eos_msg(idx))

        GLib.timeout_add(500, self._poll)

    def _on_eos_msg(self, player_idx):
        if player_idx == self._active and not self._xfading:
            GLib.idle_add(self.on_eos)

    @property
    def player(self):
        return self._players[self._active]

    def cancel_xfade(self):
        if self._xfade_timeout_id:
            try:
                GLib.source_remove(self._xfade_timeout_id)
            except Exception:
                pass
            self._xfade_timeout_id = 0
        if self._xfading:
            nxt = (self._active + 1) % 2
            self._players[nxt].set_state(Gst.State.NULL)
            self._players[self._active].set_property("volume", self._vol)
            self._xfading = False
            self._xfade_step = 0

    def load(self, path):
        self.cancel_xfade()
        self.player.set_state(Gst.State.NULL)
        self.player.set_property("uri", Gst.filename_to_uri(path))
        self.player.set_property("volume", self._vol)
        self._apply_eq_to(self._active)

    def play(self):
        self.player.set_state(Gst.State.PLAYING)

    def pause(self):
        self.player.set_state(Gst.State.PAUSED)

    def stop(self):
        self.cancel_xfade()
        for p in self._players:
            p.set_state(Gst.State.NULL)

    def seek(self, s):
        self.player.seek_simple(Gst.Format.TIME,
            Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT, int(s * Gst.SECOND))

    def set_volume(self, v):
        self._vol = v
        if not self._xfading:
            self.player.set_property("volume", v)

    def set_crossfade(self, secs):
        self._xfade_secs = secs

    def set_eq_band(self, band, gain):
        self._band_gains[band] = float(gain)
        for eq in self._eqs:
            if eq is not None:
                try:
                    eq.set_property(f"band{band}", float(gain))
                except Exception:
                    pass

    def _apply_eq_to(self, idx):
        eq = self._eqs[idx]
        if eq is None:
            return
        for i, g in enumerate(self._band_gains):
            try:
                eq.set_property(f"band{i}", g)
            except Exception:
                pass

    def load_next_for_xfade(self, path):
        if not self._xfade_secs or not path or self._xfading:
            return
        # Recalcular pasos para respetar la duracion elegida
        self._xfade_total = max(1, int(self._xfade_secs * 1000 / self.XFADE_STEP_MS))
        nxt = (self._active + 1) % 2
        self._players[nxt].set_state(Gst.State.NULL)
        self._players[nxt].set_property("uri", Gst.filename_to_uri(path))
        self._players[nxt].set_property("volume", 0.0)
        self._apply_eq_to(nxt)
        self._players[nxt].set_state(Gst.State.PLAYING)
        self._xfading = True
        self._xfade_step = 0
        GLib.timeout_add(self.XFADE_STEP_MS, self._xfade_tick)

    def _xfade_tick(self):
        if not self._xfading:
            return False
        self._xfade_step += 1
        prog = min(1.0, self._xfade_step / self._xfade_total)
        nxt = (self._active + 1) % 2
        self._players[self._active].set_property("volume", self._vol * (1 - prog))
        self._players[nxt].set_property("volume", self._vol * prog)
        if self._xfade_step >= self._xfade_total:
            self._players[self._active].set_state(Gst.State.NULL)
            self._active = nxt
            self._xfading = False
            return False
        return True

    def schedule_xfade(self, delay_ms, path):
        self.cancel_xfade()
        if delay_ms <= 0 or not path:
            return
        def _cb():
            self._xfade_timeout_id = 0
            self.load_next_for_xfade(path)
            return False
        self._xfade_timeout_id = GLib.timeout_add(delay_ms, _cb)

    def _on_err(self, msg):
        err, _ = msg.parse_error()
        GLib.idle_add(self.on_error, str(err))

    def _poll(self):
        try:
            GLib.idle_add(self.on_position, self.position, self.duration)
        except Exception:
            pass
        return True

    @property
    def position(self):
        ok, p = self.player.query_position(Gst.Format.TIME)
        return p / Gst.SECOND if ok else 0.0

    @property
    def duration(self):
        ok, d = self.player.query_duration(Gst.Format.TIME)
        return d / Gst.SECOND if ok else 0.0

    @property
    def is_playing(self):
        _, s, _ = self.player.get_state(0)
        return s == Gst.State.PLAYING

    @property
    def gst_state(self):
        _, s, _ = self.player.get_state(0)
        return s

# ══ PlayQueue ══════════════════════════════════════════════════════════
class PlayQueue:
    def __init__(self, name="Q1"):
        self.name=name; self.songs=[]; self.index=-1
        self.shuffle=False; self.repeat=REPEAT_NONE; self._order=[]

    def set_songs(self, songs, start=0):
        self.songs=list(songs)
        self.index=start if 0 <= start < len(self.songs) else -1
        self._build()

    def _build(self):
        import random
        self._order=list(range(len(self.songs)))
        if self.shuffle and self._order:
            random.shuffle(self._order)
            if 0 <= self.index < len(self.songs):
                try:
                    self._order.remove(self.index)
                except ValueError:
                    pass
                self._order.insert(0, self.index)

    @property
    def current(self):
        return self.songs[self.index] if 0 <= self.index < len(self.songs) else None

    @property
    def count(self):
        return len(self.songs)

    def _p(self):
        try:
            return self._order.index(self.index)
        except ValueError:
            return -1

    def next(self):
        if not self.songs:
            return None
        if self.repeat == REPEAT_ONE:
            return self.current
        p = self._p() + 1
        if p >= len(self._order):
            if self.repeat == REPEAT_ALL:
                p = 0
            else:
                return None
        self.index = self._order[p]
        return self.current

    def prev(self):
        if not self.songs:
            return None
        p = self._p()
        if p <= 0:
            p = 0
        else:
            p -= 1
        self.index = self._order[p]
        return self.current

    def peek_next(self):
        if not self.songs:
            return None
        if self.repeat == REPEAT_ONE:
            return self.current
        p = self._p() + 1
        if p >= len(self._order):
            if self.repeat == REPEAT_ALL:
                p = 0
            else:
                return None
        return self.songs[self._order[p]]

    def add(self, song):
        """Agrega al final sin re-shufflear el resto."""
        self.songs.append(song)
        new_idx = len(self.songs) - 1
        if self.shuffle:
            self._order.append(new_idx)
        else:
            self._order = list(range(len(self.songs)))
        if self.index < 0:
            self.index = 0

    def toggle_shuffle(self):
        self.shuffle = not self.shuffle
        self._build()

    def next_repeat(self):
        self.repeat = (self.repeat + 1) % 3
        return self.repeat

    def set_repeat(self, mode):
        self.repeat = mode

# ══ MultiQueueManager ══════════════════════════════════════════════════
class MultiQueueManager:
    NUM_QUEUES = 3
    def __init__(self):
        self.queues = [PlayQueue(f"Q{i+1}") for i in range(self.NUM_QUEUES)]
        self._active = 0
        self._on_switch_cb = None

    @property
    def queue(self):
        return self.queues[self._active]

    @property
    def active_idx(self):
        return self._active

    def switch(self, idx):
        if 0 <= idx < self.NUM_QUEUES:
            self._active = idx
            if self._on_switch_cb:
                self._on_switch_cb(idx)

    def on_switch(self, cb):
        self._on_switch_cb = cb

    def add_to_queue(self, idx, song):
        self.queues[idx].add(song)

    @property
    def songs(self): return self.queue.songs
    @property
    def index(self): return self.queue.index
    @index.setter
    def index(self, v): self.queue.index = v
    @property
    def shuffle(self): return self.queue.shuffle
    @property
    def repeat(self): return self.queue.repeat
    @property
    def current(self): return self.queue.current
    def set_songs(self, s, i=0): self.queue.set_songs(s, i)
    def next(self): return self.queue.next()
    def prev(self): return self.queue.prev()
    def peek_next(self): return self.queue.peek_next()
    def toggle_shuffle(self): self.queue.toggle_shuffle()
    def next_repeat(self): return self.queue.next_repeat()
    def set_repeat(self, m): self.queue.set_repeat(m)

# ══ MPRIS2 Service ═════════════════════════════════════════════════════
class MPRIS2Service:
    def __init__(self, win):
        self.win = win
        self._conn = None
        self._reg_ids = []
        try:
            self._conn = Gio.bus_get_sync(Gio.BusType.SESSION, None)
            Gio.bus_own_name_on_connection(
                self._conn, "org.mpris.MediaPlayer2.ArgentMusicPlayer",
                Gio.BusNameOwnerFlags.NONE, None, None)
            node = Gio.DBusNodeInfo.new_for_xml(MPRIS2_XML)
            for iface in node.interfaces:
                rid = self._conn.register_object(
                    "/org/mpris/MediaPlayer2", iface,
                    self._method, self._get, self._set)
                self._reg_ids.append(rid)
        except Exception as e:
            print(f"MPRIS2: {e}")

    def _method(self, conn, sender, path, iface, method, params, inv):
        try:
            w = self.win
            if method == "Next":
                GLib.idle_add(w._on_next)
            elif method == "Previous":
                GLib.idle_add(w._on_prev)
            elif method == "PlayPause":
                GLib.idle_add(w._on_play_pause)
            elif method == "Play":
                if not w.engine.is_playing:
                    GLib.idle_add(w._on_play_pause)
            elif method == "Pause":
                if w.engine.is_playing:
                    GLib.idle_add(w._on_play_pause)
            elif method == "Stop":
                GLib.idle_add(w._on_stop)
            elif method == "Seek":
                offset_us = params.get_child_value(0).get_int64()
                GLib.idle_add(w._mpris_seek, offset_us / 1_000_000.0)
            elif method == "SetPosition":
                pos_us = params.get_child_value(1).get_int64()
                GLib.idle_add(w._mpris_set_position, pos_us / 1_000_000.0)
            elif method == "OpenUri":
                uri = params.get_child_value(0).get_string()
                GLib.idle_add(w._mpris_open_uri, uri)
            elif method == "Raise":
                GLib.idle_add(w.present)
            elif method == "Quit":
                GLib.idle_add(w.get_application().quit)
            else:
                inv.return_dbus_error(
                    "org.freedesktop.DBus.Error.NotSupported",
                    f"Método no soportado: {method}")
                return
            inv.return_value(None)
        except Exception as e:
            inv.return_dbus_error("org.mpris.MediaPlayer2.Error", str(e))

    def _get(self, conn, sender, path, iface, prop):
        w = self.win
        s = w.mqm.current
        try:
            if iface == "org.mpris.MediaPlayer2":
                d = {
                    "CanQuit": GLib.Variant("b", True),
                    "CanRaise": GLib.Variant("b", True),
                    "HasTrackList": GLib.Variant("b", False),
                    "Identity": GLib.Variant("s", "Argent Music Player"),
                    "SupportedUriSchemes": GLib.Variant("as", ["file"]),
                    "SupportedMimeTypes": GLib.Variant("as", [
                        "audio/mpeg", "audio/flac", "audio/ogg", "audio/opus"]),
                }
                return d.get(prop)

            if iface == "org.mpris.MediaPlayer2.Player":
                if prop == "PlaybackStatus":
                    state = w.engine.gst_state
                    if state == Gst.State.PLAYING:
                        st = "Playing"
                    elif state == Gst.State.PAUSED:
                        st = "Paused"
                    else:
                        st = "Stopped"
                    return GLib.Variant("s", st)
                if prop == "LoopStatus":
                    m = w.mqm.repeat
                    return GLib.Variant("s",
                        "Track" if m == REPEAT_ONE else
                        "Playlist" if m == REPEAT_ALL else "None")
                if prop == "Rate":
                    return GLib.Variant("d", 1.0)
                if prop == "Shuffle":
                    return GLib.Variant("b", w.mqm.shuffle)
                if prop == "Metadata":
                    meta = {
                        "mpris:trackid": GLib.Variant(
                            "o", "/org/mpris/MediaPlayer2/TrackList/NoTrack")
                    }
                    if s:
                        meta["xesam:title"] = GLib.Variant("s", s.title or "")
                        meta["xesam:artist"] = GLib.Variant("as", [s.artist or ""])
                        meta["xesam:album"] = GLib.Variant("s", s.album or "")
                        meta["mpris:length"] = GLib.Variant("x", max(0, s.duration) * 1000000)
                    return GLib.Variant("a{sv}", meta)
                if prop == "Volume":
                    return GLib.Variant("d", w._vol.get_value())
                if prop == "Position":
                    return GLib.Variant("x", int(w.engine.position * 1000000))
                if prop in ("MinimumRate", "MaximumRate"):
                    return GLib.Variant("d", 1.0)
                if prop in ("CanGoNext", "CanGoPrevious", "CanPlay",
                            "CanPause", "CanSeek", "CanControl"):
                    return GLib.Variant("b", True)
        except Exception:
            pass
        if prop in ("CanQuit", "CanRaise", "CanGoNext", "CanGoPrevious",
                    "CanPlay", "CanPause", "CanSeek", "CanControl"):
            return GLib.Variant("b", True)
        if prop in ("Rate", "MinimumRate", "MaximumRate", "Volume"):
            return GLib.Variant("d", 1.0 if prop != "Volume" else 0.0)
        if prop == "PlaybackStatus":
            return GLib.Variant("s", "Stopped")
        if prop == "LoopStatus":
            return GLib.Variant("s", "None")
        if prop == "Shuffle":
            return GLib.Variant("b", False)
        if prop == "Position":
            return GLib.Variant("x", 0)
        if prop == "Metadata":
            return GLib.Variant("a{sv}", {
                "mpris:trackid": GLib.Variant(
                    "o", "/org/mpris/MediaPlayer2/TrackList/NoTrack")
            })
        return None

    def _set(self, conn, sender, path, iface, prop, value):
        w = self.win
        try:
            if prop == "Volume":
                v = max(0.0, min(1.0, value.get_double()))
                GLib.idle_add(w._vol.set_value, v)
                return True
            if prop == "LoopStatus":
                s = value.get_string()
                target = {"None": REPEAT_NONE, "Track": REPEAT_ONE,
                          "Playlist": REPEAT_ALL}.get(s)
                if target is None:
                    return False
                def _apply_loop():
                    w.mqm.set_repeat(target)
                    w._update_repeat_button()
                    w.mpris.notify()
                GLib.idle_add(_apply_loop)
                return True
            if prop == "Shuffle":
                want = value.get_boolean()
                def _apply_shuffle():
                    if w.mqm.shuffle != want:
                        w.mqm.toggle_shuffle()
                    w._bsh.set_active(want)
                    w.mpris.notify()
                GLib.idle_add(_apply_shuffle)
                return True
            if prop == "Rate":
                return False
        except Exception:
            return False
        return False

    def notify(self):
        if not self._conn:
            return
        try:
            props = {}
            for k in ("PlaybackStatus", "Metadata", "LoopStatus",
                      "Shuffle", "Volume"):
                v = self._get(None, None, None,
                              "org.mpris.MediaPlayer2.Player", k)
                if v is not None:
                    props[k] = v
            self._conn.emit_signal(
                None, "/org/mpris/MediaPlayer2",
                "org.freedesktop.DBus.Properties", "PropertiesChanged",
                GLib.Variant("(sa{sv}as)",
                             ("org.mpris.MediaPlayer2.Player", props, [])))
        except Exception:
            pass

# ══ GObject wrappers ═══════════════════════════════════════════════════
class SongObject(GObj.Object):
    __gtype_name__ = "SongObject"
    def __init__(self, song, pos):
        super().__init__()
        self.song = song
        self.position = pos

class StrObj(GObj.Object):
    __gtype_name__ = "StrObj"
    def __init__(self, text, data=None):
        super().__init__()
        self.text = text
        self.data = data

# ══ TagEditorDialog ════════════════════════════════════════════════════
class TagEditorDialog(Adw.Dialog):
    def __init__(self, song, on_save, parent):
        super().__init__()
        self.song = song
        self._on_save = on_save
        self.set_title("Editor de etiquetas")
        self.set_content_width(480)
        self.set_content_height(560)
        self._new_cover = None

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        hdr = Adw.HeaderBar()
        self._title_widget = Adw.WindowTitle(
            title="Editor de etiquetas", subtitle=song.filename)
        hdr.set_title_widget(self._title_widget)
        save_btn = Gtk.Button(label="Guardar")
        save_btn.add_css_class("suggested-action")
        save_btn.connect("clicked", self._save)
        hdr.pack_end(save_btn)
        box.append(hdr)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        inner.set_margin_top(16); inner.set_margin_bottom(16)
        inner.set_margin_start(16); inner.set_margin_end(16)

        cover_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        cover_box.set_halign(Gtk.Align.CENTER)
        self._cover_pic = Gtk.Picture()
        self._cover_pic.set_size_request(140, 140)
        self._cover_pic.add_css_class("cover-art")
        self._cover_pic.set_content_fit(Gtk.ContentFit.COVER)
        pb = song.get_pixbuf()
        if pb:
            self._cover_pic.set_pixbuf(pb)
        ch_btn = Gtk.Button(label="Cambiar portada")
        ch_btn.add_css_class("flat")
        ch_btn.connect("clicked", self._change_cover)
        cover_box.append(self._cover_pic)
        cover_box.append(ch_btn)
        inner.append(cover_box)

        grp = Adw.PreferencesGroup(title="Informacion")
        self._f_title  = self._row(grp, "Titulo",   song.title)
        self._f_artist = self._row(grp, "Artista",  song.artist)
        self._f_album  = self._row(grp, "Album",    song.album)
        self._f_genre  = self._row(grp, "Genero",   song.genre)
        self._f_track  = self._row(grp, "Num. pista",
                                   str(song.tracknumber) if song.tracknumber else "")
        inner.append(grp)

        info_grp = Adw.PreferencesGroup(title="Archivo")
        info_grp.add(Adw.ActionRow(title="Ruta", subtitle=song.path))
        info_grp.add(Adw.ActionRow(title="Duracion", subtitle=song.duration_str))
        info_grp.add(Adw.ActionRow(
            title="Formato", subtitle=Path(song.path).suffix.upper()[1:]))
        inner.append(info_grp)

        scroll.set_child(inner)
        box.append(scroll)
        self.set_child(box)
        self.present(parent)

    def _row(self, grp, title, val):
        row = Adw.EntryRow(title=title)
        row.set_text(val)
        grp.add(row)
        return row

    def _change_cover(self, _):
        d = Gtk.FileDialog()
        d.set_title("Seleccionar imagen")
        ff = Gtk.FileFilter()
        ff.set_name("Imagenes")
        ff.add_mime_type("image/jpeg")
        ff.add_mime_type("image/png")
        filters = Gio.ListStore.new(Gtk.FileFilter)
        filters.append(ff)
        d.set_filters(filters)
        d.open(None, None, self._cover_chosen)

    def _cover_chosen(self, dialog, result):
        try:
            f = dialog.open_finish(result)
            if f:
                with open(f.get_path(), "rb") as fh:
                    self._new_cover = fh.read()
                # Redimensionar si supera 8 MB
                if len(self._new_cover) > 8 * 1024 * 1024:
                    self._title_widget.set_subtitle("Imagen demasiado grande (>8 MB)")
                    self._new_cover = None
                    return
                ld = GdkPixbuf.PixbufLoader()
                ld.write(self._new_cover)
                ld.close()
                self._cover_pic.set_pixbuf(ld.get_pixbuf())
        except Exception as e:
            print(f"[tag] cover: {e}")

    def _save(self, _):
        title  = self._f_title.get_text().strip()
        artist = self._f_artist.get_text().strip()
        album  = self._f_album.get_text().strip()
        genre  = self._f_genre.get_text().strip()
        try:
            track = int(self._f_track.get_text().strip() or "0")
        except ValueError:
            track = 0

        try:
            ext = Path(self.song.path).suffix.lower()
            if ext in (".opus", ".ogg"):
                from mutagen.oggopus import OggOpus
                from mutagen.oggvorbis import OggVorbis
                audio = OggOpus(self.song.path) if ext == ".opus" else OggVorbis(self.song.path)
                if audio.tags is None:
                    audio.add_tags()
                audio.tags["title"]  = [title]
                audio.tags["artist"] = [artist]
                audio.tags["album"]  = [album]
                audio.tags["genre"]  = [genre]
                if track:
                    audio.tags["tracknumber"] = [str(track)]
                audio.save()
            else:
                audio = MutagenFile(self.song.path, easy=True)
                if audio is not None:
                    audio["title"]  = [title]
                    audio["artist"] = [artist]
                    audio["album"]  = [album]
                    audio["genre"]  = [genre]
                    if track:
                        audio["tracknumber"] = [str(track)]
                    audio.save()

            self.song.title = title
            self.song.artist = artist
            self.song.album = album
            self.song.genre = genre
            self.song.tracknumber = track
            if self._new_cover:
                self.song.cover = self._new_cover
                self.song._cover_loaded = True
                self.song._pixbuf_cache = None
            if self._on_save:
                self._on_save(self.song)
            self.close()
        except Exception as e:
            print(f"Tag save error: {e}")
            self._title_widget.set_subtitle(f"Error al guardar: {e}")

# ══ EQDialog ═══════════════════════════════════════════════════════════
class EQDialog(Adw.Dialog):
    FREQ_LABELS = ["29Hz","59Hz","119Hz","237Hz","474Hz","947Hz","1.9kHz","3.8kHz","7.5kHz","15kHz"]

    def __init__(self, engine, parent):
        super().__init__()
        self.engine = engine
        self.set_title("Ecualizador")
        self.set_content_width(520)
        self.set_content_height(380)
        self._sliders = []

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        hdr = Adw.HeaderBar()
        hdr.set_title_widget(Adw.WindowTitle(title="Ecualizador 10 bandas"))
        box.append(hdr)

        if not engine.eq_available:
            lbl = Gtk.Label(
                label="Instala gstreamer1.0-plugins-bad para habilitar el ecualizador")
            lbl.set_wrap(True)
            lbl.set_margin_top(32)
            lbl.add_css_class("dim-label")
            box.append(lbl)
            self.set_child(box)
            self.present(parent)
            return

        pbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        pbox.set_margin_start(16); pbox.set_margin_end(16); pbox.set_margin_top(12)
        plbl = Gtk.Label(label="Preset:")
        plbl.add_css_class("dim-label")
        combo = Gtk.DropDown.new_from_strings(list(EQ_PRESETS.keys()))
        combo.connect("notify::selected", self._on_preset)
        combo.set_hexpand(True)
        pbox.append(plbl)
        pbox.append(combo)
        box.append(pbox)

        eq_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        eq_box.set_margin_start(12); eq_box.set_margin_end(12)
        eq_box.set_margin_top(12); eq_box.set_margin_bottom(16)
        eq_box.set_vexpand(True)

        for i, label in enumerate(self.FREQ_LABELS):
            col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            col.set_hexpand(True)
            col.set_halign(Gtk.Align.CENTER)
            sl = Gtk.Scale.new_with_range(Gtk.Orientation.VERTICAL, -12, 12, 0.5)
            sl.set_draw_value(True)
            sl.set_vexpand(True)
            sl.set_inverted(True)
            sl.add_mark(0, Gtk.PositionType.RIGHT, "0")
            try:
                cur = engine._band_gains[i]
            except Exception:
                cur = 0.0
            sl.set_value(cur)
            sl.connect("value-changed", self._on_band, i)
            self._sliders.append(sl)
            lbl = Gtk.Label(label=label)
            lbl.add_css_class("caption")
            lbl.add_css_class("dim-label")
            col.append(sl)
            col.append(lbl)
            eq_box.append(col)

        box.append(eq_box)
        rst = Gtk.Button(label="Restablecer")
        rst.add_css_class("flat")
        rst.set_halign(Gtk.Align.CENTER)
        rst.set_margin_bottom(8)
        rst.connect("clicked", self._reset)
        box.append(rst)
        self.set_child(box)
        self.present(parent)

    def _on_band(self, sl, band):
        self.engine.set_eq_band(band, sl.get_value())

    def _on_preset(self, combo, _):
        name = list(EQ_PRESETS.keys())[combo.get_selected()]
        vals = EQ_PRESETS[name]
        for i, (sl, v) in enumerate(zip(self._sliders, vals)):
            sl.set_value(v)
            self.engine.set_eq_band(i, v)

    def _reset(self, _):
        for i, sl in enumerate(self._sliders):
            sl.set_value(0)
            self.engine.set_eq_band(i, 0)

# ══ XfadeDialog ════════════════════════════════════════════════════════
class XfadeDialog(Adw.Dialog):
    def __init__(self, engine, parent):
        super().__init__()
        self.engine = engine
        self.set_title("Fundido entre canciones")
        self.set_content_width(360)
        self.set_content_height(200)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        hdr = Adw.HeaderBar()
        hdr.set_title_widget(Adw.WindowTitle(title="Fundido (Crossfade)"))
        box.append(hdr)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        inner.set_margin_top(20); inner.set_margin_bottom(20)
        inner.set_margin_start(20); inner.set_margin_end(20)
        lbl = Gtk.Label(label="Duracion del fundido entre canciones:")
        lbl.set_halign(Gtk.Align.START)
        sl = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 10, 0.5)
        sl.set_value(engine._xfade_secs)
        sl.set_draw_value(True)
        sl.add_mark(0, Gtk.PositionType.BOTTOM, "Off")
        sl.add_mark(3, Gtk.PositionType.BOTTOM, "3s")
        sl.add_mark(6, Gtk.PositionType.BOTTOM, "6s")
        sl.add_mark(10, Gtk.PositionType.BOTTOM, "10s")
        sl.connect("value-changed", lambda sc: engine.set_crossfade(sc.get_value()))
        inner.append(lbl)
        inner.append(sl)
        note = Gtk.Label(label="0 = desactivado")
        note.add_css_class("dim-label")
        note.add_css_class("caption")
        inner.append(note)
        box.append(inner)
        self.set_child(box)
        self.present(parent)

# ══ Utilidad: color dominante de portada ═══════════════════════════════
def dominant_color(pixbuf):
    try:
        thumb = pixbuf.scale_simple(32, 32, GdkPixbuf.InterpType.BILINEAR)
        n_channels = thumb.get_n_channels()
        data = thumb.get_pixels()
        w, h = thumb.get_width(), thumb.get_height()
        rowstride = thumb.get_rowstride()
        best_score = -1
        best = (70, 130, 180)
        for y in range(h):
            for x in range(w):
                off = y * rowstride + x * n_channels
                r, g, b = data[off], data[off+1], data[off+2]
                rf, gf, bf = r/255, g/255, b/255
                cmax, cmin = max(rf,gf,bf), min(rf,gf,bf)
                l = (cmax + cmin) / 2
                s = 0 if cmax == cmin else (cmax - cmin) / (1 - abs(2*l - 1))
                lightness_ok = 0.2 < l < 0.8
                score = s * (1 - abs(2*l - 0.55)) if lightness_ok else 0
                if score > best_score:
                    best_score = score
                    best = (r, g, b)
        return best
    except Exception:
        return (70, 130, 180)

def color_is_dark(r, g, b):
    return (0.299*r + 0.587*g + 0.114*b) < 128

# ══ LRC Parser + Manager ════════════════════════════════════════════════
import re as _re, urllib.request, urllib.parse, json as _json

def parse_lrc(text):
    """Soporta [offset:+/-ms] y precision de milisegundos."""
    offset_ms = 0
    off_re = _re.compile(r'\[offset:\s*([+-]?\d+)\s*\]', _re.IGNORECASE)
    m_off = off_re.search(text)
    if m_off:
        try:
            offset_ms = int(m_off.group(1))
        except ValueError:
            offset_ms = 0

    lines = []
    tag_re = _re.compile(r'\[(\d{2}):(\d{2})[.:]?(\d{0,3})\]')
    for raw in text.splitlines():
        raw = raw.strip()
        tags = list(tag_re.finditer(raw))
        if not tags:
            continue
        lyric = raw[tags[-1].end():].strip()
        for m in tags:
            ms_group = m.group(3)
            if ms_group:
                frac = int(ms_group) / (10 ** len(ms_group))
            else:
                frac = 0.0
            t = int(m.group(1)) * 60 + int(m.group(2)) + frac + offset_ms / 1000.0
            lines.append((max(0.0, t), lyric))
    lines.sort(key=lambda x: x[0])
    return lines

class LyricsManager:
    def __init__(self):
        self._cache = {}

    def get(self, song, callback):
        if song.path in self._cache:
            GLib.idle_add(callback, self._cache[song.path])
            return
        threading.Thread(target=self._fetch, args=(song, callback), daemon=True).start()

    def _fetch(self, song, callback):
        lines = self._try_local(song) or self._try_online(song) or []
        self._cache[song.path] = lines
        GLib.idle_add(callback, lines)

    def _try_local(self, song):
        lrc_path = Path(song.path).with_suffix(".lrc")
        if lrc_path.exists():
            try:
                t = lrc_path.read_text(encoding="utf-8", errors="replace")
                l = parse_lrc(t)
                if l:
                    return l
            except Exception:
                pass
        return None

    def _try_online(self, song):
        params = urllib.parse.urlencode({
            "artist_name": song.artist,
            "track_name": song.title,
            "album_name": song.album,
            "duration": song.duration,
        })
        hdrs = {
            "User-Agent": "ArgentMusicPlayer/1.1.3 (https://github.com/Tavo78ok/argent-music-player)",
            "Accept": "application/json",
            "Lrclib-Client": "ArgentMusicPlayer v1.1.3 (https://github.com/Tavo78ok/argent-music-player)",
        }
        for timeout in (12, 20):
            try:
                req = urllib.request.Request(
                    f"https://lrclib.net/api/get?{params}", headers=hdrs)
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    data = _json.loads(r.read())
                lrc = data.get("syncedLyrics") or ""
                if lrc:
                    l = parse_lrc(lrc)
                    if l:
                        return l
                plain = data.get("plainLyrics") or ""
                if plain:
                    return [(i * 3.0, ln) for i, ln in enumerate(plain.splitlines()) if ln.strip()]
                return None
            except urllib.error.HTTPError as e:
                print(f"[LRC] HTTP {e.code}: {song.title}")
                return None
            except Exception as e:
                print(f"[LRC] Reintentando ({timeout}s): {e}")
        return None

    def current_index(self, lines, pos):
        idx = 0
        for i, (t, _) in enumerate(lines):
            if t <= pos:
                idx = i
            else:
                break
        return idx

class FolderRow(Gtk.ListBoxRow):
    def __init__(self, folder_path=None):
        super().__init__()
        self.folder_path = folder_path

# ══ Main Window ════════════════════════════════════════════════════════
class ArgentMusicPlayer(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title("Argent Music Player")
        self.set_default_size(1080, 700)
        self.set_size_request(720, 520)

        self.db = MusicDatabase()
        self.mqm = MultiQueueManager()
        self.engine = AudioEngine(self._on_eos, self._on_eng_err, self._update_pos)
        self.mpris = MPRIS2Service(self)
        self._seeking = False
        self._folder = None
        self._ss = None
        self._lrc_lines = []
        self._lrc_index = -1
        self._show_lyrics = False
        self._lrc_token = 0
        self._lyrics_mgr = LyricsManager()
        self._scan_cancel = None
        self._prev_highlight_idx = -1
        self._err_count = 0
        self._cover_color_token = 0

        self._cfg = load_config()
        saved_scheme = self._cfg.get("color_scheme")
        if saved_scheme == "dark":
            Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        elif saved_scheme == "light":
            Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_LIGHT)

        self._dynamic_css = Gtk.CssProvider()
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), self._dynamic_css,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
        self._build_ui()
        self._apply_css()
        songs = self.db.all_songs()
        if songs:
            self._populate(songs)

    def _apply_css(self):
        p = Gtk.CssProvider()
        p.load_from_data(b"""
        .cover-art { border-radius: 12px; }
        .cover-ph { border-radius: 12px; background-color: alpha(@accent_color, .1); }
        .song-title { font-size: 17px; font-weight: bold; }
        .song-artist { font-size: 13px; }
        .row-title { font-size: 13px; font-weight: 500; }
        .row-sub { font-size: 11px; }
        .time-label { font-size: 12px; font-variant-numeric: tabular-nums; }
        .active-row { background-color: alpha(@accent_color, .15); border-radius: 8px; }
        .lib-title { font-size: 13px; font-weight: 600; }
        .lib-sub { font-size: 11px; }
        .queue-btn { font-size: 11px; font-weight: 600; min-width: 32px; padding: 2px 6px; }
        .queue-btn-active { background-color: alpha(@accent_color, .2); }
        .lrc-line { font-size: 13px; padding: 3px 0; }
        .lrc-active { font-size: 15px; font-weight: bold; color: @accent_color; }
        .lrc-inactive { opacity: 0.45; }
        .lyrics-box { border-radius: 12px; background-color: alpha(@card_bg_color, 0.6); }
        """)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def _build_ui(self):
        hdr = Adw.HeaderBar()
        self._wtitle = Adw.WindowTitle(title="Argent Music Player", subtitle="Biblioteca")
        hdr.set_title_widget(self._wtitle)
        ob = Gtk.Button(icon_name="document-open-symbolic", tooltip_text="Abrir carpeta")
        ob.connect("clicked", self._on_open)
        hdr.pack_start(ob)
        self._sbtn = Gtk.ToggleButton(icon_name="system-search-symbolic", tooltip_text="Buscar")
        self._sbtn.connect("toggled", self._on_search_toggled)
        hdr.pack_end(self._sbtn)
        mb = Gtk.MenuButton(icon_name="open-menu-symbolic")
        mb.set_menu_model(self._build_menu())
        hdr.pack_end(mb)
        self._theme_btn = Gtk.Button(tooltip_text="Cambiar tema")
        self._theme_btn.add_css_class("flat")
        self._theme_btn.connect("clicked", self._on_toggle_theme)
        hdr.pack_end(self._theme_btn)
        self._update_theme_btn()

        self._sbar = Gtk.SearchBar()
        self._sentry = Gtk.SearchEntry(placeholder_text="Buscar en la biblioteca...")
        self._sentry.connect("search-changed", self._on_search_changed)
        self._sbar.set_child(self._sentry)
        self._sbar.connect_entry(self._sentry)
        self._sbtn.bind_property(
            "active", self._sbar, "search-mode-enabled",
            GObj.BindingFlags.BIDIRECTIONAL)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.append(hdr)
        root.append(self._sbar)
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned.set_vexpand(True)
        paned.set_position(315)
        paned.set_start_child(self._build_player())
        paned.set_shrink_start_child(False)
        paned.set_resize_start_child(False)
        paned.set_end_child(self._build_library())
        root.append(paned)
        self.set_content(root)

    def _build_player(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.set_size_request(295, -1)
        box.add_css_class("background")
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        inner.set_margin_top(18); inner.set_margin_bottom(6)
        inner.set_margin_start(14); inner.set_margin_end(14)
        inner.set_vexpand(True)

        cover_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        cover_outer.set_halign(Gtk.Align.CENTER)
        self._cstack = Gtk.Stack()
        self._cstack.set_size_request(190, 190)
        self._cstack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
        self._cstack.set_transition_duration(250)
        ph = Gtk.Box()
        ph.add_css_class("cover-ph")
        ph.set_size_request(190, 190)
        ic = Gtk.Image.new_from_icon_name("audio-x-generic-symbolic")
        ic.set_pixel_size(56)
        ic.set_opacity(0.3)
        ic.set_hexpand(True)
        ic.set_valign(Gtk.Align.CENTER)
        ph.append(ic)
        self._cstack.add_named(ph, "ph")
        self._cimg = Gtk.Picture()
        self._cimg.set_size_request(190, 190)
        self._cimg.add_css_class("cover-art")
        self._cimg.set_content_fit(Gtk.ContentFit.COVER)
        self._cstack.add_named(self._cimg, "cover")
        lf = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        lf.add_css_class("lyrics-box")
        lf.set_size_request(190, 190)
        lsw = Gtk.ScrolledWindow()
        lsw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        lsw.set_size_request(190, 190)
        lsw.set_vexpand(True)
        self._lyrics_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self._lyrics_box.set_margin_top(8); self._lyrics_box.set_margin_bottom(8)
        self._lyrics_box.set_margin_start(10); self._lyrics_box.set_margin_end(10)
        self._lyrics_vadj = lsw.get_vadjustment()
        lsw.set_child(self._lyrics_box)
        self._lrc_ph = Gtk.Label(label="Sin letras")
        self._lrc_ph.add_css_class("dim-label")
        self._lrc_ph.add_css_class("caption")
        self._lrc_ph.set_valign(Gtk.Align.CENTER)
        self._lrc_ph.set_vexpand(True)
        lf.append(self._lrc_ph)
        lf.append(lsw)
        self._cstack.add_named(lf, "lyrics")
        self._lrc_btn = Gtk.Button(
            icon_name="format-justify-left-symbolic", tooltip_text="Mostrar letras")
        self._lrc_btn.add_css_class("flat")
        self._lrc_btn.set_halign(Gtk.Align.CENTER)
        self._lrc_btn.connect("clicked", self._on_toggle_lyrics)
        cover_outer.append(self._cstack)
        cover_outer.append(self._lrc_btn)
        inner.append(cover_outer)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info.set_halign(Gtk.Align.CENTER)
        self._lt = Gtk.Label(label="Sin reproduccion")
        self._lt.add_css_class("song-title")
        self._lt.set_ellipsize(Pango.EllipsizeMode.END)
        self._lt.set_max_width_chars(22)
        self._lar = Gtk.Label(label="—")
        self._lar.add_css_class("song-artist")
        self._lar.add_css_class("dim-label")
        self._lar.set_ellipsize(Pango.EllipsizeMode.END)
        self._lar.set_max_width_chars(26)
        self._lab = Gtk.Label(label="")
        self._lab.add_css_class("caption")
        self._lab.add_css_class("dim-label")
        self._lab.set_ellipsize(Pango.EllipsizeMode.END)
        self._lab.set_max_width_chars(26)
        info.append(self._lt)
        info.append(self._lar)
        info.append(self._lab)
        inner.append(info)

        sb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self._seek = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 0.01)
        self._seek.set_draw_value(False)
        self._seek.set_hexpand(True)
        self._seek.connect("change-value", self._on_seek_change)
        sg = Gtk.GestureClick.new()
        sg.connect("pressed", lambda *_: setattr(self, "_seeking", True))
        sg.connect("released", self._on_seek_rel)
        self._seek.add_controller(sg)
        tr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self._lpos = Gtk.Label(label="0:00")
        self._lpos.add_css_class("time-label")
        self._ldur = Gtk.Label(label="0:00")
        self._ldur.add_css_class("time-label")
        sp = Gtk.Label()
        sp.set_hexpand(True)
        tr.append(self._lpos)
        tr.append(sp)
        tr.append(self._ldur)
        sb.append(self._seek)
        sb.append(tr)
        inner.append(sb)

        ctrl = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        ctrl.set_halign(Gtk.Align.CENTER)
        self._bsh = Gtk.ToggleButton(
            icon_name="media-playlist-shuffle-symbolic", tooltip_text="Aleatorio")
        self._bsh.connect("toggled", lambda b: self.mqm.toggle_shuffle())
        bpv = Gtk.Button(icon_name="media-skip-backward-symbolic", tooltip_text="Anterior")
        bpv.connect("clicked", self._on_prev)
        self._bpl = Gtk.Button(icon_name="media-playback-start-symbolic")
        self._bpl.add_css_class("suggested-action")
        self._bpl.add_css_class("circular")
        self._bpl.connect("clicked", self._on_play_pause)
        bnx = Gtk.Button(icon_name="media-skip-forward-symbolic", tooltip_text="Siguiente")
        bnx.connect("clicked", self._on_next)
        self._brp = Gtk.Button(
            icon_name="media-playlist-repeat-symbolic", tooltip_text="Repetir")
        self._brp.connect("clicked", self._on_repeat)
        for w in (self._bsh, bpv, self._bpl, bnx, self._brp):
            w.add_css_class("flat")
            ctrl.append(w)
        inner.append(ctrl)

        vb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self._vico = Gtk.Image.new_from_icon_name("audio-volume-medium-symbolic")
        self._vico.set_pixel_size(16)
        self._vol = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 0.01)
        self._vol.set_value(1.0)
        self._vol.set_draw_value(False)
        self._vol.set_hexpand(True)
        self._vol.connect("value-changed", self._on_vol)
        vb.append(self._vico)
        vb.append(self._vol)
        inner.append(vb)

        qbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        qbox.set_halign(Gtk.Align.CENTER)
        qlbl = Gtk.Label(label="Cola:")
        qlbl.add_css_class("dim-label")
        qlbl.add_css_class("caption")
        qbox.append(qlbl)
        self._qbtns = []
        for i in range(MultiQueueManager.NUM_QUEUES):
            btn = Gtk.ToggleButton(label=f"Q{i+1}")
            btn.add_css_class("flat")
            btn.add_css_class("queue-btn")
            btn.connect("toggled", self._on_queue_btn, i)
            self._qbtns.append(btn)
            qbox.append(btn)
        self._qbtns[0].set_active(True)
        qadd = Gtk.Button(icon_name="list-add-symbolic", tooltip_text="Agregar a cola")
        qadd.add_css_class("flat")
        qadd.connect("clicked", self._on_add_to_queue)
        qbox.append(qadd)
        inner.append(qbox)

        tools = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        tools.set_halign(Gtk.Align.CENTER)
        eq_btn = Gtk.Button(
            icon_name="multimedia-equalizer-symbolic", tooltip_text="Ecualizador")
        eq_btn.add_css_class("flat")
        eq_btn.connect("clicked", lambda _: EQDialog(self.engine, self))
        xf_btn = Gtk.Button(
            icon_name="media-record-symbolic", tooltip_text="Fundido entre canciones")
        xf_btn.add_css_class("flat")
        xf_btn.connect("clicked", lambda _: XfadeDialog(self.engine, self))
        tag_btn = Gtk.Button(
            icon_name="document-edit-symbolic", tooltip_text="Editar etiquetas")
        tag_btn.add_css_class("flat")
        tag_btn.connect("clicked", self._on_edit_tags)
        for w in (eq_btn, xf_btn, tag_btn):
            tools.append(w)
        inner.append(tools)

        stb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        stb.set_halign(Gtk.Align.CENTER)
        self._spin = Gtk.Spinner()
        self._spin.set_visible(False)
        self._lstat = Gtk.Label(label="")
        self._lstat.add_css_class("caption")
        self._lstat.add_css_class("dim-label")
        stb.append(self._spin)
        stb.append(self._lstat)
        inner.append(stb)
        box.append(inner)
        return box

    def _build_library(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._vstack = Adw.ViewStack()
        self._vstack.set_vexpand(True)

        self._ss = Gio.ListStore.new(SongObject)
        self._sf = Gtk.FilterListModel.new(
            self._ss, Gtk.CustomFilter.new(self._sfunc, None))
        lv = self._make_song_lv(self._sf)
        self._slv = lv
        self._vstack.add_titled_with_icon(
            self._wrap(lv), "songs", "Canciones", "audio-x-generic-symbolic")

        self._as_al = Gio.ListStore.new(StrObj)
        self._vstack.add_titled_with_icon(
            self._wrap(self._make_lib_lv(self._as_al, self._on_album_act, "album")),
            "albums", "Albums", "media-optical-symbolic")

        self._as_ar = Gio.ListStore.new(StrObj)
        self._vstack.add_titled_with_icon(
            self._wrap(self._make_lib_lv(self._as_ar, self._on_artist_act, "artist")),
            "artists", "Artistas", "system-users-symbolic")

        self._as_ge = Gio.ListStore.new(StrObj)
        self._vstack.add_titled_with_icon(
            self._wrap(self._make_lib_lv(self._as_ge, self._on_genre_act, "genre")),
            "genres", "Generos", "applications-multimedia-symbolic")

        self._folder_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._vstack.add_titled_with_icon(
            self._wrap(self._folder_box), "folders", "Carpetas", "folder-music-symbolic")

        bar = Adw.ViewSwitcherBar()
        bar.set_stack(self._vstack)
        bar.set_reveal(True)
        self._vstack.connect("notify::visible-child-name", self._on_view_changed)
        box.append(self._vstack)
        box.append(bar)
        return box

    def _wrap(self, w):
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        sw.set_child(w)
        return sw

    def _make_song_lv(self, model):
        lv = Gtk.ListView()
        lv.add_css_class("navigation-sidebar")
        f = Gtk.SignalListItemFactory()
        f.connect("setup", self._setup_song_row)
        f.connect("bind", self._bind_song_row)
        sel = Gtk.SingleSelection.new(model)
        self._song_sel = sel
        lv.set_model(sel)
        lv.set_factory(f)
        lv.connect("activate", self._on_song_act)
        return lv

    def _setup_song_row(self, _, item):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.set_margin_start(8); row.set_margin_end(8)
        row.set_margin_top(4); row.set_margin_bottom(4)
        num = Gtk.Label()
        num.set_width_chars(3)
        num.add_css_class("dim-label")
        num.add_css_class("row-sub")
        num.set_xalign(1)
        tb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        tb.set_hexpand(True)
        tl = Gtk.Label()
        tl.add_css_class("row-title")
        tl.set_halign(Gtk.Align.START)
        tl.set_ellipsize(Pango.EllipsizeMode.END)
        sl = Gtk.Label()
        sl.add_css_class("row-sub")
        sl.add_css_class("dim-label")
        sl.set_halign(Gtk.Align.START)
        sl.set_ellipsize(Pango.EllipsizeMode.END)
        tb.append(tl)
        tb.append(sl)
        dl = Gtk.Label()
        dl.add_css_class("row-sub")
        dl.add_css_class("dim-label")
        row.append(num)
        row.append(tb)
        row.append(dl)
        item.set_child(row)

    def _bind_song_row(self, _, item):
        obj = item.get_item()
        s = obj.song
        row = item.get_child()
        ws = []
        c = row.get_first_child()
        while c:
            ws.append(c)
            c = c.get_next_sibling()
        num, tb, dl = ws
        tl = tb.get_first_child()
        sl = tl.get_next_sibling()
        num.set_label(str(obj.position + 1))
        tl.set_label(s.display_title)
        sl.set_label(f"{s.artist} · {s.album}" if s.album else s.artist)
        dl.set_label(s.duration_str)
        if self.mqm.index == obj.position:
            row.add_css_class("active-row")
        else:
            row.remove_css_class("active-row")

    def _make_lib_lv(self, store, on_act, mode):
        lv = Gtk.ListView()
        lv.add_css_class("navigation-sidebar")
        f = Gtk.SignalListItemFactory()
        f.connect("setup", lambda _, i: self._setup_lib_row(_, i, mode))
        f.connect("bind", lambda _, i: self._bind_lib_row(_, i, mode))
        lv.set_model(Gtk.SingleSelection.new(store))
        lv.set_factory(f)
        lv.connect("activate", on_act)
        return lv

    def _setup_lib_row(self, _, item, mode):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        row.set_margin_start(12); row.set_margin_end(12)
        row.set_margin_top(6); row.set_margin_bottom(6)
        icons = {
            "album": "media-optical-symbolic",
            "artist": "avatar-default-symbolic",
            "genre": "applications-multimedia-symbolic",
        }
        ico = Gtk.Image.new_from_icon_name(icons[mode])
        ico.set_pixel_size(32)
        ico.set_opacity(0.5)
        tb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        tb.set_hexpand(True)
        tl = Gtk.Label()
        tl.add_css_class("lib-title")
        tl.set_halign(Gtk.Align.START)
        tl.set_ellipsize(Pango.EllipsizeMode.END)
        sl = Gtk.Label()
        sl.add_css_class("lib-sub")
        sl.add_css_class("dim-label")
        sl.set_halign(Gtk.Align.START)
        tb.append(tl)
        tb.append(sl)
        arr = Gtk.Image.new_from_icon_name("go-next-symbolic")
        arr.set_opacity(0.3)
        row.append(ico)
        row.append(tb)
        row.append(arr)
        item.set_child(row)

    def _bind_lib_row(self, _, item, mode):
        obj = item.get_item()
        row = item.get_child()
        ws = []
        c = row.get_first_child()
        while c:
            ws.append(c)
            c = c.get_next_sibling()
        _, tb, _ = ws
        tl = tb.get_first_child()
        sl = tl.get_next_sibling()
        tl.set_label(obj.text)
        if obj.data is not None:
            if mode == "album":
                artist, count = obj.data
                sl.set_label(f"{artist}  ·  {count} canciones")
            elif mode == "artist":
                sl.set_label(f"{obj.data} canciones")
            elif mode == "genre":
                sl.set_label(f"{obj.data} canciones")

    def _build_menu(self):
        m = Gio.Menu()
        m.append("Abrir carpeta", "app.open_folder")
        m.append("Reescanear biblioteca", "app.rescan")
        s1 = Gio.Menu()
        s1.append("Importar lista M3U", "app.import_m3u")
        s1.append("Exportar lista M3U", "app.export_m3u")
        m.append_section("Listas de reproducción", s1)
        m.append("Mini reproductor", "app.mini_player")
        m.append("Acerca de", "app.about")
        return m

    # ── Search ──────────────────────────────
    def _sfunc(self, item, _):
        q = self._sentry.get_text().strip().lower()
        if not q:
            return True
        s = item.song
        return (q in s.title.lower() or q in s.artist.lower() or q in s.album.lower())

    def _on_search_toggled(self, btn):
        if not btn.get_active():
            self._sentry.set_text("")
            # search-changed ya llama a _rfilter

    def _on_search_changed(self, _):
        self._rfilter()

    def _rfilter(self):
        f = self._sf.get_filter()
        if f:
            f.changed(Gtk.FilterChange.DIFFERENT)

    # ── Folder ──────────────────────────────
    def _on_open(self, _=None):
        d = Gtk.FileDialog()
        d.set_title("Seleccionar carpeta de musica")
        d.select_folder(self, None, self._folder_cb)

    def _folder_cb(self, dialog, result):
        try:
            f = dialog.select_folder_finish(result)
            if f:
                self._load_folder(f.get_path())
        except GLib.Error:
            pass

    def _load_folder(self, folder):
        if self._scan_cancel is not None:
            self._scan_cancel.set()
        self._folder = folder
        if self.db.is_indexed(folder) and not self.db.needs_rescan(folder):
            self.db.remove_missing(folder)
            songs = self.db.songs_in_folder(folder)
            self._populate(songs)
            self._lstat.set_label(f"{len(songs)} canciones")
            return
        self._scan(folder)

    def _scan(self, folder):
        self._spin.set_visible(True)
        self._spin.start()
        self._lstat.set_label("Escaneando...")
        cancel = threading.Event()
        self._scan_cancel = cancel

        def work():
            songs = []
            count = 0
            for root, _, files in os.walk(folder):
                if cancel.is_set():
                    return
                for f in sorted(files):
                    if cancel.is_set():
                        return
                    if Path(f).suffix.lower() in SUPPORTED_FORMATS:
                        s = Song.from_path(os.path.join(root, f))
                        self.db.upsert(s, folder)
                        songs.append(s)
                        count += 1
                        if count % 80 == 0:
                            self.db.commit()
                            GLib.idle_add(self._lstat.set_label,
                                          f"Escaneando... {count}")
            if cancel.is_set():
                return
            self.db.commit()
            self.db.remove_missing(folder)
            GLib.idle_add(self._scan_done, songs)

        threading.Thread(target=work, daemon=True).start()

    def _scan_done(self, songs):
        self._spin.stop()
        self._spin.set_visible(False)
        self._scan_cancel = None
        self._populate(songs)
        self._lstat.set_label(f"{len(songs)} canciones")

    def _populate(self, songs):
        self._ss.remove_all()
        for i, s in enumerate(songs):
            self._ss.append(SongObject(s, i))
        self.mqm.set_songs(songs, 0)
        self._prev_highlight_idx = -1
        self._as_al.remove_all()
        for album, artist, count in self.db.all_albums():
            self._as_al.append(StrObj(album, (artist, count)))
        self._as_ar.remove_all()
        for artist, count in self.db.all_artists():
            self._as_ar.append(StrObj(artist, count))
        self._as_ge.remove_all()
        for genre, count in self.db.all_genres():
            self._as_ge.append(StrObj(genre, count))
        self._wtitle.set_subtitle(f"{len(songs)} canciones en biblioteca")

    # ── Library activations ──────────────────
    def _on_album_act(self, _, pos):
        obj = self._as_al.get_item(pos)
        if obj:
            self._subview(f"Album: {obj.text}",
                          self.db.songs_by_album(obj.text, obj.data[0]))

    def _on_artist_act(self, _, pos):
        obj = self._as_ar.get_item(pos)
        if obj:
            self._subview(f"Artista: {obj.text}",
                          self.db.songs_by_artist(obj.text))

    def _on_genre_act(self, _, pos):
        obj = self._as_ge.get_item(pos)
        if obj:
            self._subview(f"Genero: {obj.text}",
                          self.db.songs_by_genre(obj.text))

    def _subview(self, title, songs):
        dlg = Adw.Dialog()
        dlg.set_title(title)
        dlg.set_content_width(560)
        dlg.set_content_height(520)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        hdr = Adw.HeaderBar()
        hdr.set_title_widget(Adw.WindowTitle(
            title=title, subtitle=f"{len(songs)} canciones"))
        box.append(hdr)
        pa = Gtk.Button(label="Reproducir todo")
        pa.add_css_class("suggested-action")
        pa.set_margin_start(12); pa.set_margin_end(12)
        pa.set_margin_top(8); pa.set_margin_bottom(4)
        pa.connect("clicked", lambda _: self._play_list(songs, 0, dlg))
        box.append(pa)
        store = Gio.ListStore.new(SongObject)
        for i, s in enumerate(songs):
            store.append(SongObject(s, i))
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        lv = Gtk.ListView()
        lv.add_css_class("navigation-sidebar")
        f = Gtk.SignalListItemFactory()
        f.connect("setup", self._setup_song_row)

        def bind_sub(_, item):
            obj2 = item.get_item()
            s2 = obj2.song
            row = item.get_child()
            ws = []
            c = row.get_first_child()
            while c:
                ws.append(c)
                c = c.get_next_sibling()
            num, tb, dl = ws
            tl = tb.get_first_child()
            sl = tl.get_next_sibling()
            num.set_label(str(obj2.position + 1))
            tl.set_label(s2.display_title)
            sl.set_label(f"{s2.artist} · {s2.album}" if s2.album else s2.artist)
            dl.set_label(s2.duration_str)

        f.connect("bind", bind_sub)
        lv.set_model(Gtk.SingleSelection.new(store))
        lv.set_factory(f)
        lv.connect("activate", lambda lv2, p: self._play_list(songs, p, dlg))
        sw.set_child(lv)
        box.append(sw)
        dlg.set_child(box)
        dlg.present(self)

    def _play_list(self, songs, start, dlg=None):
        if dlg:
            dlg.close()
        self.mqm.set_songs(songs, start)
        self._ss.remove_all()
        for i, s in enumerate(songs):
            self._ss.append(SongObject(s, i))
        self._prev_highlight_idx = -1
        self._vstack.set_visible_child_name("songs")
        self._play_current()

    # ── Multi-queue ─────────────────────────
    def _on_queue_btn(self, btn, idx):
        if not btn.get_active():
            return
        for i, b in enumerate(self._qbtns):
            if i != idx:
                b.set_active(False)
        self.mqm.switch(idx)
        if self._ss is None:
            return
        songs = self.mqm.songs
        self._ss.remove_all()
        for i, s in enumerate(songs):
            self._ss.append(SongObject(s, i))
        self._prev_highlight_idx = -1
        nq = self.mqm.queue.count
        self._lstat.set_label(f"Cola Q{idx+1}: {nq} canciones")
        s = self.mqm.current
        if s:
            self._update_player(s)
        else:
            self._reset_player_ui()
        self._sync_list_highlight()
        self.mpris.notify()

    def _on_add_to_queue(self, _):
        s = self.mqm.current
        if not s:
            return
        nxt = (self.mqm.active_idx + 1) % MultiQueueManager.NUM_QUEUES
        self.mqm.add_to_queue(nxt, s)
        self._lstat.set_label(f"Agregado a Q{nxt+1}")

    # ── Tag editor ──────────────────────────
    def _on_edit_tags(self, _):
        s = self.mqm.current
        if not s:
            return
        TagEditorDialog(s, self._on_tags_saved, self)

    def _on_tags_saved(self, song):
        self.db.update_tags(
            song.path, song.title, song.artist,
            song.album, song.genre, song.tracknumber)
        self._update_player(song)
        n = self._ss.get_n_items()
        if n:
            self._ss.items_changed(0, n, n)

    # ── Playback ────────────────────────────
    def _on_song_act(self, _, pos):
        obj = self._sf.get_item(pos)
        if not obj:
            return
        self.mqm.index = obj.position
        self._play_current()

    def _sync_list_highlight(self):
        """Resalta solo las filas afectadas; sincroniza la selección visible."""
        idx = self.mqm.index
        n = self._ss.get_n_items()
        prev = self._prev_highlight_idx
        if prev != idx:
            for i in (prev, idx):
                if 0 <= i < n:
                    self._ss.items_changed(i, 1, 1)
            self._prev_highlight_idx = idx
        if not hasattr(self, "_song_sel") or self._song_sel is None:
            return
        model = self._song_sel.get_model()
        n_vis = model.get_n_items()
        for i in range(n_vis):
            obj = model.get_item(i)
            if obj is not None and getattr(obj, "position", -1) == idx:
                self._song_sel.set_selected(i)
                try:
                    if self._slv is not None:
                        self._slv.scroll_to(i, Gtk.ListScrollFlags.NONE, None)
                except Exception:
                    pass
                break

    def _reset_player_ui(self):
        self._lt.set_label("Sin reproducción")
        self._lar.set_label("—")
        self._lab.set_label("")
        self._wtitle.set_subtitle("Biblioteca")
        self._seek.set_range(0, 1)
        self._seek.set_value(0)
        self._lpos.set_label("0:00")
        self._ldur.set_label("0:00")
        self._bpl.set_icon_name("media-playback-start-symbolic")
        self._cstack.set_visible_child_name("ph")
        self._reset_cover_color()

    def _play_current(self):
        s = self.mqm.current
        if not s:
            return
        try:
            s.load_cover()
            self.engine.load(s.path)
            self.engine.play()
        except Exception as e:
            print(f"[play] {e}")
            self._on_eng_err(str(e))
            return
        self._err_count = 0
        self._update_player(s)

        nxt = self.mqm.peek_next()
        # No hacer crossfade si el siguiente es la misma canción (REPEAT_ONE)
        if (self.engine._xfade_secs > 0 and nxt is not None and nxt is not s
                and s.duration > self.engine._xfade_secs):
            delay_ms = int((s.duration - self.engine._xfade_secs) * 1000)
            self.engine.schedule_xfade(delay_ms, nxt.path)

        self._sync_list_highlight()
        self.mpris.notify()
        if hasattr(self, "_mini_win") and self._mini_win:
            GLib.idle_add(self._mini_win.update_song, s)

        self._lrc_lines = []
        self._lrc_index = -1
        self._lrc_token = id(s)
        if self._show_lyrics:
            self._load_lyrics(s)

    def _update_player(self, s):
        self._bpl.set_icon_name("media-playback-pause-symbolic")
        self._lt.set_label(s.display_title)
        self._lar.set_label(s.artist or "Artista desconocido")
        self._lab.set_label(s.album or "")
        self._wtitle.set_subtitle(f"{s.title} — {s.artist}")
        self._seek.set_range(0, max(s.duration, 1))
        self._seek.set_value(0)
        self._ldur.set_label(s.duration_str)
        self._load_cover(s)

    def _load_cover(self, s):
        pb = s.get_pixbuf() if s.cover else None
        if pb:
            try:
                try:
                    texture = Gdk.Texture.new_for_pixbuf(pb)
                    self._cimg.set_paintable(texture)
                except Exception:
                    self._cimg.set_pixbuf(pb)
                self._cstack.set_visible_child_name("cover")
                token = object()
                self._cover_color_token = token

                def _color_thread(pb2, tok):
                    color = dominant_color(pb2)
                    GLib.idle_add(self._apply_cover_color_checked, tok, *color)

                threading.Thread(
                    target=_color_thread, args=(pb, token), daemon=True).start()
                return
            except Exception:
                pass
        self._cstack.set_visible_child_name("ph")
        self._reset_cover_color()

    def _apply_cover_color_checked(self, token, r, g, b):
        if getattr(self, "_cover_color_token", None) is not token:
            return
        self._apply_cover_color_rgb(r, g, b)

    def _apply_cover_color_rgb(self, r, g, b):
        is_dark = Adw.StyleManager.get_default().get_dark()
        fg = "white" if color_is_dark(r, g, b) else "#111111"
        if is_dark:
            r2, g2, b2 = (min(255, int(r*1.3)),
                          min(255, int(g*1.3)),
                          min(255, int(b*1.3)))
        else:
            r2, g2, b2 = int(r*0.78), int(g*0.78), int(b*0.78)
        css_rules = [
            f".active-row {{ background-color: rgba({r},{g},{b},0.18); border-radius: 8px; }}",
            f".cover-ph {{ background-color: rgba({r},{g},{b},0.10); }}",
            f"scale trough highlight {{ background-color: rgb({r},{g},{b}); }}",
            f"button.suggested-action {{ background-color: rgb({r2},{g2},{b2}); color: {fg}; }}",
            f"button.suggested-action:hover {{ background-color: rgb({min(255,r2+20)},{min(255,g2+20)},{min(255,b2+20)}); color: {fg}; }}",
        ]
        self._dynamic_css.load_from_data(("\n".join(css_rules)).encode())

    def _reset_cover_color(self):
        self._cover_color_token = object()
        self._dynamic_css.load_from_data(b"")

    def _on_play_pause(self, _=None):
        if not self.mqm.current:
            if self.mqm.songs:
                self._play_current()
            return
        if self.engine.is_playing:
            self.engine.pause()
            self._bpl.set_icon_name("media-playback-start-symbolic")
        else:
            self.engine.play()
            self._bpl.set_icon_name("media-playback-pause-symbolic")
        self.mpris.notify()

    def _on_stop(self):
        self.engine.stop()
        self._bpl.set_icon_name("media-playback-start-symbolic")
        self.mpris.notify()

    def _on_next(self, _=None):
        self.engine.cancel_xfade()
        if self.mqm.next():
            self._play_current()
        else:
            self.engine.stop()
            self._bpl.set_icon_name("media-playback-start-symbolic")
            self.mpris.notify()

    def _on_prev(self, _=None):
        self.engine.cancel_xfade()
        if self.engine.position > 3.0:
            self.engine.seek(0)
        else:
            self.mqm.prev()
            self._play_current()

    def _on_eos(self):
        self._on_next()

    def _on_eng_err(self, msg):
        self._err_count = getattr(self, "_err_count", 0) + 1
        self._lstat.set_label(f"Error de reproducción: {msg[:60]}")
        if self._err_count >= 5:
            self.engine.stop()
            self._bpl.set_icon_name("media-playback-start-symbolic")
            self._lstat.set_label("Demasiados errores seguidos — detenido")
            self.mpris.notify()
            self._err_count = 0
            return
        self._on_next()

    def _on_repeat(self, _):
        self.mqm.next_repeat()
        self._update_repeat_button()

    def _update_repeat_button(self):
        m = self.mqm.repeat
        self._brp.set_icon_name(
            "media-playlist-repeat-song-symbolic" if m == REPEAT_ONE
            else "media-playlist-repeat-symbolic")
        if m == REPEAT_ALL:
            self._brp.add_css_class("suggested-action")
        else:
            self._brp.remove_css_class("suggested-action")

    # ── MPRIS helpers ────────────────────────
    def _mpris_seek(self, offset_secs):
        new_pos = max(0.0, self.engine.position + offset_secs)
        self.engine.seek(new_pos)
        self.mpris.notify()

    def _mpris_set_position(self, pos_secs):
        self.engine.seek(max(0.0, pos_secs))
        self.mpris.notify()

    def _mpris_open_uri(self, uri):
        try:
            if uri.startswith("file://"):
                path = urllib.parse.unquote(urllib.parse.urlparse(uri).path)
            else:
                path = uri
            if (Path(path).suffix.lower() in SUPPORTED_FORMATS
                    and Path(path).exists()):
                song = Song.from_path(path)
                self.mqm.set_songs([song], 0)
                self._play_current()
        except Exception as e:
            print(f"[MPRIS] OpenUri: {e}")

    def _on_seek_change(self, _, __, v):
        if self._seeking:
            m, s = divmod(int(v), 60)
            self._lpos.set_label(f"{m}:{s:02d}")
        return False

    def _on_seek_rel(self, *_):
        self.engine.seek(self._seek.get_value())
        self._seeking = False

    def _on_vol(self, sc):
        v = sc.get_value()
        self.engine.set_volume(v)
        self._vico.set_from_icon_name(
            "audio-volume-muted-symbolic" if v == 0 else
            "audio-volume-low-symbolic" if v < .33 else
            "audio-volume-medium-symbolic" if v < .66 else
            "audio-volume-high-symbolic")
        self.mpris.notify()

    def _update_pos(self, pos, dur):
        if self._seeking or dur == 0:
            return
        self._seek.set_value(pos)
        m, s = divmod(int(pos), 60)
        self._lpos.set_label(f"{m}:{s:02d}")
        if self._show_lyrics and self._lrc_lines:
            self._sync_lyrics(pos)
        # Backup de precarga si el schedule falló
        if (self.engine._xfade_secs > 0 and dur > 0 and
                not self.engine._xfading and
                self.engine._xfade_timeout_id == 0):
            remaining = dur - pos
            if 0 < remaining <= self.engine._xfade_secs:
                cur = self.mqm.current
                nxt = self.mqm.peek_next()
                if nxt is not None and nxt is not cur:
                    self.engine.load_next_for_xfade(nxt.path)

    # ── Letras LRC ─────────────────────────────
    def _on_toggle_lyrics(self, _):
        self._show_lyrics = not self._show_lyrics
        if self._show_lyrics:
            self._cstack.set_visible_child_name("lyrics")
            self._lrc_btn.set_icon_name("image-x-generic-symbolic")
            self._lrc_btn.set_tooltip_text("Mostrar portada")
            if not self._lrc_lines:
                s = self.mqm.current
                if s:
                    self._load_lyrics(s)
        else:
            s = self.mqm.current
            self._cstack.set_visible_child_name(
                "cover" if (s and s.cover) else "ph")
            self._lrc_btn.set_icon_name("format-justify-left-symbolic")
            self._lrc_btn.set_tooltip_text("Mostrar letras")

    def _load_lyrics(self, song):
        self._lrc_token = id(song)
        token = self._lrc_token
        self._lrc_lines = []
        self._lrc_index = -1
        self._lrc_ph.set_label("Buscando letras...")
        self._lrc_ph.set_visible(True)
        c = self._lyrics_box.get_first_child()
        while c:
            n = c.get_next_sibling()
            self._lyrics_box.remove(c)
            c = n

        def on_loaded(lines):
            if self._lrc_token != token:
                return
            self._lrc_lines = lines
            self._lrc_index = -1
            if not lines:
                self._lrc_ph.set_label("Sin letras disponibles")
                self._lrc_ph.set_visible(True)
                return
            self._lrc_ph.set_visible(False)
            for _t, txt in lines:
                lbl = Gtk.Label(label=txt or "·")
                lbl.add_css_class("lrc-line")
                lbl.add_css_class("lrc-inactive")
                lbl.set_wrap(True)
                lbl.set_xalign(0.5)
                self._lyrics_box.append(lbl)
            self._sync_lyrics(self.engine.position)

        self._lyrics_mgr.get(song, on_loaded)

    def _sync_lyrics(self, pos):
        if not self._lrc_lines:
            return
        new_idx = self._lyrics_mgr.current_index(self._lrc_lines, pos)
        if new_idx == self._lrc_index:
            return
        self._lrc_index = new_idx
        labels = []
        c = self._lyrics_box.get_first_child()
        while c:
            labels.append(c)
            c = c.get_next_sibling()
        for i, lbl in enumerate(labels):
            if i == new_idx:
                lbl.remove_css_class("lrc-inactive")
                lbl.add_css_class("lrc-active")
            else:
                lbl.remove_css_class("lrc-active")
                lbl.add_css_class("lrc-inactive")
        if 0 <= new_idx < len(labels):
            GLib.idle_add(self._scroll_to_lrc, labels[new_idx])

    def _scroll_to_lrc(self, lbl):
        try:
            adj = self._lyrics_vadj
            ok, x, y = lbl.translate_coordinates(self._lyrics_box, 0, 0)
            if ok:
                h = lbl.get_height() or 20
                center = y + h / 2
                page = adj.get_page_size()
                adj.set_value(max(0, min(center - page / 2, adj.get_upper() - page)))
        except Exception:
            pass
        return False

    def _on_toggle_theme(self, _):
        mgr = Adw.StyleManager.get_default()
        current = mgr.get_color_scheme()
        if current == Adw.ColorScheme.FORCE_DARK:
            mgr.set_color_scheme(Adw.ColorScheme.FORCE_LIGHT)
            self._cfg["color_scheme"] = "light"
        else:
            mgr.set_color_scheme(Adw.ColorScheme.FORCE_DARK)
            self._cfg["color_scheme"] = "dark"
        save_config(self._cfg)
        self._update_theme_btn()
        s = self.mqm.current
        if s and s.cover:
            pb = s.get_pixbuf()
            if pb:
                color = dominant_color(pb)
                self._apply_cover_color_rgb(*color)

    def _update_theme_btn(self):
        mgr = Adw.StyleManager.get_default()
        is_dark = mgr.get_dark()
        icon = "weather-clear-symbolic" if is_dark else "weather-clear-night-symbolic"
        tip = "Cambiar a modo claro" if is_dark else "Cambiar a modo oscuro"
        self._theme_btn.set_icon_name(icon)
        self._theme_btn.set_tooltip_text(tip)

    # ── Vista de carpetas ───────────────────────
    def _on_view_changed(self, stack, _):
        if stack.get_visible_child_name() == "folders":
            self._build_folder_tree()

    def _build_folder_tree(self):
        c = self._folder_box.get_first_child()
        while c:
            n = c.get_next_sibling()
            self._folder_box.remove(c)
            c = n

        folders = self.db.folder_list()

        if not folders:
            lbl = Gtk.Label(label="Abre una carpeta de música primero")
            lbl.add_css_class("dim-label")
            lbl.set_margin_top(32)
            self._folder_box.append(lbl)
            return

        root_map = {}
        for folder in folders:
            parts = Path(folder).parts
            cur = root_map
            for p in parts:
                cur = cur.setdefault(p, {})
            cur["__path__"] = folder

        lb = Gtk.ListBox()
        lb.set_selection_mode(Gtk.SelectionMode.NONE)
        lb.add_css_class("navigation-sidebar")
        lb.connect("row-activated", lambda lb, row: self._on_folder_row_act(row))
        self._add_folder_rows(lb, root_map, 0)
        self._folder_box.append(lb)

    def _add_folder_rows(self, lb, node, depth):
        for key, child in sorted(node.items()):
            if key == "__path__":
                continue
            path = child.get("__path__")
            row = FolderRow(folder_path=path)
            hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            hbox.set_margin_start(12 + depth * 16)
            hbox.set_margin_end(12)
            hbox.set_margin_top(6)
            hbox.set_margin_bottom(6)
            icon = Gtk.Image.new_from_icon_name(
                "folder-music-symbolic" if path else "folder-symbolic")
            icon.set_pixel_size(20)
            icon.set_opacity(0.7)
            name_lbl = Gtk.Label(label=key)
            name_lbl.set_halign(Gtk.Align.START)
            name_lbl.set_hexpand(True)
            name_lbl.add_css_class("lib-title")
            hbox.append(icon)
            hbox.append(name_lbl)
            if path:
                cnt = self.db.folder_count(path)
                sub = Gtk.Label(label=f"{cnt} canciones")
                sub.add_css_class("dim-label")
                sub.add_css_class("caption")
                hbox.append(sub)
                arr = Gtk.Image.new_from_icon_name("go-next-symbolic")
                arr.set_opacity(0.3)
                hbox.append(arr)
                row.set_activatable(True)
            row.set_child(hbox)
            lb.append(row)
            subkeys = {k: v for k, v in child.items() if k != "__path__"}
            if subkeys:
                self._add_folder_rows(lb, child, depth + 1)

    def _on_folder_row_act(self, row):
        if not isinstance(row, FolderRow) or not row.folder_path:
            return
        songs = self.db.songs_in_folder(row.folder_path)
        if songs:
            self._subview(f"📁 {Path(row.folder_path).name}", songs)
        else:
            self._lstat.set_label(
                f"Sin canciones en {Path(row.folder_path).name}")

    # ── Listas M3U ──────────────────────────────
    def _export_m3u(self, songs, path):
        try:
            lines = ["#EXTM3U"]
            for s in songs:
                lines.append(f"#EXTINF:{s.duration},{s.artist} - {s.title}")
                lines.append(s.path)
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            return True
        except Exception:
            return False

    def _import_m3u(self, m3u_path):
        songs = []
        seen = set()
        m3u_dir = Path(m3u_path).parent
        try:
            with open(m3u_path, "r", encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            for line in lines:
                line = line.strip()
                if line.startswith("#") or not line:
                    continue
                line = line.replace("\\", "/")
                p = Path(line)
                if not p.is_absolute():
                    p = m3u_dir / p
                p = p.resolve()
                sp = str(p)
                if p.exists() and sp not in seen:
                    try:
                        s = Song.from_path(sp)
                        songs.append(s)
                        seen.add(sp)
                    except Exception:
                        pass
        except Exception as e:
            print(f"[M3U] Error: {e}")
        return songs

    def _on_export_m3u(self, _=None):
        songs = self.mqm.songs
        if not songs:
            self._lstat.set_label("No hay canciones en la cola")
            return
        d = Gtk.FileDialog()
        d.set_title("Exportar lista M3U")
        ff = Gtk.FileFilter()
        ff.set_name("Listas M3U (*.m3u)")
        ff.add_pattern("*.m3u")
        ff.add_pattern("*.M3U")
        fls = Gio.ListStore.new(Gtk.FileFilter)
        fls.append(ff)
        d.set_filters(fls)
        d.set_initial_name("lista.m3u")
        d.save(self, None, self._m3u_save_cb)

    def _m3u_save_cb(self, dialog, result):
        try:
            f = dialog.save_finish(result)
            if f:
                ok = self._export_m3u(self.mqm.songs, f.get_path())
                self._lstat.set_label(
                    "Lista exportada ✓" if ok else "Error al exportar")
        except GLib.Error:
            pass

    def _on_import_m3u(self, _=None):
        d = Gtk.FileDialog()
        d.set_title("Importar lista M3U")
        ff = Gtk.FileFilter()
        ff.set_name("Listas M3U (*.m3u)")
        ff.add_pattern("*.m3u")
        ff.add_pattern("*.M3U")
        fls = Gio.ListStore.new(Gtk.FileFilter)
        fls.append(ff)
        d.set_filters(fls)
        d.open(self, None, self._m3u_open_cb)

    def _m3u_open_cb(self, dialog, result):
        try:
            f = dialog.open_finish(result)
            if f:
                songs = self._import_m3u(f.get_path())
                if songs:
                    self._play_list(songs, 0)
                    self._lstat.set_label(f"M3U: {len(songs)} canciones")
                else:
                    self._lstat.set_label("No se encontraron archivos en la lista")
        except GLib.Error:
            pass

    # ── Mini reproductor flotante ────────────────
    def _on_mini_player(self, _=None):
        if hasattr(self, "_mini_win") and self._mini_win:
            self._mini_win.present()
            if not self._mini_win._tick_id:
                self._mini_win._start_tick()
            return
        self._mini_win = MiniPlayer(self)
        self._mini_win.present()


# ══ Mini Reproductor Flotante ═══════════════════════════════════════════
class MiniPlayer(Gtk.Window):
    def __init__(self, main_win):
        super().__init__()
        self.main = main_win
        self.set_title("Argent Music")
        self.set_default_size(280, 96)
        self.set_resizable(False)
        self.connect("realize", self._set_keep_above_wm)
        self.set_decorated(True)
        self.connect("close-request", self._on_close)
        self._tick_id = 0

        p = Gtk.CssProvider()
        p.load_from_data(b"""
        .mini-cover { border-radius: 8px; }
        .mini-title { font-size: 13px; font-weight: bold; }
        .mini-artist { font-size: 11px; }
        .mini-bg { background-color: alpha(@card_bg_color, 0.95); }
        """)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), p,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.add_css_class("mini-bg")

        self._seek = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 0.01)
        self._seek.set_draw_value(False)
        self._seek.set_size_request(-1, 4)
        self._seek.add_css_class("flat")
        sg = Gtk.GestureClick.new()
        sg.connect("released", self._on_seek)
        self._seek.add_controller(sg)
        root.append(self._seek)

        main_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_row.set_margin_start(10); main_row.set_margin_end(10)
        main_row.set_margin_top(8); main_row.set_margin_bottom(8)

        self._cover_stack = Gtk.Stack()
        self._cover_stack.set_size_request(64, 64)
        ph = Gtk.Box()
        ph.add_css_class("cover-ph")
        ph.set_size_request(64, 64)
        ic = Gtk.Image.new_from_icon_name("audio-x-generic-symbolic")
        ic.set_pixel_size(28)
        ic.set_opacity(0.3)
        ic.set_hexpand(True)
        ic.set_valign(Gtk.Align.CENTER)
        ph.append(ic)
        self._cover_stack.add_named(ph, "ph")
        self._cover = Gtk.Picture()
        self._cover.set_size_request(64, 64)
        self._cover.add_css_class("mini-cover")
        self._cover.set_content_fit(Gtk.ContentFit.COVER)
        self._cover_stack.add_named(self._cover, "cover")
        main_row.append(self._cover_stack)

        info_ctrl = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        info_ctrl.set_hexpand(True)
        info_ctrl.set_valign(Gtk.Align.CENTER)

        self._lbl_t = Gtk.Label(label="Sin reproducción")
        self._lbl_t.add_css_class("mini-title")
        self._lbl_t.set_halign(Gtk.Align.START)
        self._lbl_t.set_ellipsize(Pango.EllipsizeMode.END)
        self._lbl_a = Gtk.Label(label="—")
        self._lbl_a.add_css_class("mini-artist")
        self._lbl_a.add_css_class("dim-label")
        self._lbl_a.set_halign(Gtk.Align.START)
        self._lbl_a.set_ellipsize(Pango.EllipsizeMode.END)
        info_ctrl.append(self._lbl_t)
        info_ctrl.append(self._lbl_a)

        ctrl = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        btn_prev = Gtk.Button(icon_name="media-skip-backward-symbolic")
        btn_prev.add_css_class("flat")
        btn_prev.connect("clicked", lambda _: main_win._on_prev())
        self._btn_play = Gtk.Button(icon_name="media-playback-start-symbolic")
        self._btn_play.add_css_class("flat")
        self._btn_play.connect("clicked", lambda _: main_win._on_play_pause())
        btn_next = Gtk.Button(icon_name="media-skip-forward-symbolic")
        btn_next.add_css_class("flat")
        btn_next.connect("clicked", lambda _: main_win._on_next())
        btn_expand = Gtk.Button(
            icon_name="view-restore-symbolic",
            tooltip_text="Abrir reproductor completo")
        btn_expand.add_css_class("flat")
        btn_expand.connect("clicked", self._on_expand)
        for b in (btn_prev, self._btn_play, btn_next, btn_expand):
            ctrl.append(b)
        info_ctrl.append(ctrl)
        main_row.append(info_ctrl)
        root.append(main_row)
        self.set_child(root)

        self._sync_from_main()
        self._start_tick()

    def _start_tick(self):
        if self._tick_id:
            return
        self._tick_id = GLib.timeout_add(500, self._tick)

    def _sync_from_main(self):
        s = self.main.mqm.current
        if s:
            self._lbl_t.set_label(s.display_title)
            self._lbl_a.set_label(s.artist)
            self._seek.set_range(0, max(s.duration, 1))
            pb = s.get_pixbuf() if s.cover else None
            if pb:
                try:
                    tex = Gdk.Texture.new_for_pixbuf(pb)
                    self._cover.set_paintable(tex)
                except Exception:
                    try:
                        self._cover.set_pixbuf(pb)
                    except Exception:
                        pass
                self._cover_stack.set_visible_child_name("cover")
            else:
                self._cover_stack.set_visible_child_name("ph")
        if self.main.engine.is_playing:
            self._btn_play.set_icon_name("media-playback-pause-symbolic")
        else:
            self._btn_play.set_icon_name("media-playback-start-symbolic")

    def _tick(self):
        # Nunca matar el timer: si la ventana está oculta simplemente se omite
        if self.get_visible():
            try:
                pos = self.main.engine.position
                dur = self.main.engine.duration
                if dur > 0:
                    self._seek.set_value(pos)
                if self.main.engine.is_playing:
                    self._btn_play.set_icon_name("media-playback-pause-symbolic")
                else:
                    self._btn_play.set_icon_name("media-playback-start-symbolic")
                s = self.main.mqm.current
                if s:
                    self._lbl_t.set_label(s.display_title)
                    self._lbl_a.set_label(s.artist)
            except Exception:
                pass
        return True

    def _on_seek(self, gesture, n, x, y):
        val = self._seek.get_value()
        self.main.engine.seek(val)

    def _on_expand(self, _):
        self.main.present()
        self.close()

    def _set_keep_above_wm(self, _):
        try:
            surface = self.get_surface()
            if hasattr(surface, "set_keep_above"):
                surface.set_keep_above(True)
        except Exception:
            pass

    def _on_close(self, _):
        if self._tick_id:
            try:
                GLib.source_remove(self._tick_id)
            except Exception:
                pass
            self._tick_id = 0
        self.main._mini_win = None
        return False

    def update_song(self, s):
        try:
            self._lbl_t.set_label(s.display_title)
            self._lbl_a.set_label(s.artist)
            self._seek.set_range(0, max(s.duration, 1))
            pb = s.get_pixbuf() if s.cover else None
            if pb:
                try:
                    tex = Gdk.Texture.new_for_pixbuf(pb)
                    self._cover.set_paintable(tex)
                except Exception:
                    try:
                        self._cover.set_pixbuf(pb)
                    except Exception:
                        pass
                self._cover_stack.set_visible_child_name("cover")
                return
        except Exception:
            pass
        try:
            self._cover_stack.set_visible_child_name("ph")
        except Exception:
            pass

# ══ Application ════════════════════════════════════════════════════════
class ArgentMusicApp(Adw.Application):
    def __init__(self):
        GLib.set_prgname("argent-music-player")
        GLib.set_application_name("Argent Music Player")
        super().__init__(
            application_id="io.github.Tavo78ok.ArgentMusicPlayer",
            flags=Gio.ApplicationFlags.HANDLES_OPEN)
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.DEFAULT)
        self.connect("activate", self._on_activate)
        self.win = None
        for name, cb in [
            ("open_folder", lambda a, p: self.win._on_open()),
            ("rescan",      lambda a, p: self.win._scan(self.win._folder)
                                         if self.win and self.win._folder else None),
            ("import_m3u",  lambda a, p: self.win._on_import_m3u()),
            ("export_m3u",  lambda a, p: self.win._on_export_m3u()),
            ("mini_player", lambda a, p: self.win._on_mini_player()),
            ("about",       self._about),
        ]:
            act = Gio.SimpleAction.new(name, None)
            act.connect("activate", cb)
            self.add_action(act)

    def _on_activate(self, _):
        if self.win is None:
            self.win = ArgentMusicPlayer(self)
        self.win.present()

    def do_open(self, files, n_files, hint):
        if self.win is None:
            self.win = ArgentMusicPlayer(self)
        paths = [f.get_path() for f in files if f.get_path()]
        songs = [Song.from_path(p) for p in paths
                 if Path(p).suffix.lower() in SUPPORTED_FORMATS]
        if songs:
            self.win._play_list(songs, 0)
        self.win.present()

    def _about(self, *_):
        Adw.AboutDialog(
            application_name="Argent Music Player",
            application_icon="argent-music-player",
            version="1.1.3",
            developer_name="Andrés",
            website="https://github.com/Tavo78ok/argent-music-player",
            issue_url="https://github.com/Tavo78ok/argent-music-player/issues",
            comments=("Reproductor de música local con ecualizador, "
                      "fundido entre canciones, colas múltiples, "
                      "letras sincronizadas, mini reproductor e integración MPRIS2."),
            license_type=Gtk.License.GPL_3_0).present(self.win)

def main():
    app = ArgentMusicApp()
    sys.exit(app.run(sys.argv))

if __name__ == "__main__":
    main()